
const Owner=(props)=>{
  return(
    <>
    <h3>{props.title} by {props.name} Michael</h3><br/>
    </>
  );
}

export default Owner;