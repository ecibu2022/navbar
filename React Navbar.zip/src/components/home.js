import "../styles.css";
import Owner from "./owner";

  const Home=()=>{
    return(
      <div className="home"><br/>
        <h4>Home Page</h4><br/>
        <div>
          <form>
              <input type="text" placeholder="Username"/>
              <br/>
              <br/>
              <input type="text" placeholder="Password"/>
              <br/>
              <br/>
              <button>Save</button>
          </form>
        </div><br/>
        <Owner title="Coded" name="Ecibu"/>
      </div>
    );
  }

  export default Home;