import "../styles.css";
import Owner from "./owner";

const Contact=()=>{
  return(
    <div className="contact"><br/>
    <h2>Contact Us</h2><br/>
    <Owner title="Code made" name="Ecibu"/>
    </div>
  );
}

export default Contact;