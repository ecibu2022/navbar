import "./styles.css";
import Home from "./components/home";
import Contact from "./components/contact";
import React from "react";
import {BrowserRouter as Router, Routes, Route, Link} from "react-router-dom";

class App extends React.Component {
  render(){
    return (
   <Router>
    <div className="App">
     <nav>
      <ul>
        <li className="logo">Logo</li>
        <li><Link to="/" className="link">Home</Link></li>
        <li><Link to="/contact" className="link">Contact</Link></li>
      </ul>
      </nav>
    </div>

      <Routes>
`         <Route path="/" element={<Home/>}></Route>
          <Route path="/contact" element={<Contact/>}></Route>
      </Routes>

    </Router>
  );
  }
}


export default App;